How to use :

Copy the repositery in the root of your lem-in
Go in the folder and launch make (make val="off" if you don't want to use valgrind)


If you want to add more map, add it with the right name in the folder valid_map or unvalid_map.

If you add a valid map, be sure that you put in the first two comment at the top the count optimum and the count with the shortest path only

If you add an unvalid map, be sure to add a commentary at the top who describe why it should be false.

Have fun
